#pragma once

#include <algorithm>
#include <vector>

// =============================================================================
// ZERO-CONTAINERS - CONSIGNES GENERALES
//
// Implementez les conteneurs suivants en ecrivant un minimum de code a l'aide
// de std::vector comme seul container, et des algorithmes de la bibliotheque
// standard. Vous devez ecrire le moins de code possible en suivant la regle du
// zero; par exemple vous ne *devez pas* implementer vous-meme les semantiques
// de transfert ou de copie.
//
// Soyez flemmard-e-s, et n'implementez que les fonctions qui sont decrites pour
// chaque conteneur.
// =============================================================================

// circular_buffer_t

//  circular_buffer_t &push_back(T val)
// Ajoute une valeur a la fin du circular buffer.

//  circular_buffer_t &insert(std::size_t pos, T val)
// Insere une valeur a une position donnee dans le circular buffer. L'insertion
// doit pouvoir se faire avec une coordonnee superieure a la taille du
// conteneur, en suivant la meme logique que l'operator[].

//  circular_buffer_t &erase(std::size_t pos)
// Supprime une valeur a une position donnee dans le circular buffer, toujours
// en suivant la meme logique que l'operator[] et insert.

//  T const &operator[](std::size_t i) const
// Permet d'acceder a une reference constante vers l'element d'indice i. Le
// conteneur etant un buffer "circulaire", on considere qu'on revient au debut
// du conteneur lorsqu'on depasse la valeur max de l'indice.

//  T &operator[](std::size_t i)
// Permet d'acceder a une reference vers l'element d'indice i. Le conteneur
// etant un buffer "circulaire", on considere qu'on revient au debut du
// conteneur lorsqu'on depasse la valeur max de l'indice.

//  std::size_t size() const
// Renvoie le nombre d'elements dans le circular buffer.

template <typename T> struct circular_buffer_t {
  // écrire votre code ici
  private:
    std::vector<T> data_;

    // Méthode auxiliaire pour obtenir l'indice circulaire
    std::size_t circular_index(std::size_t i) const {
        return i % data_.size();
    }

  public:
    circular_buffer_t &push_back(T val) {
        data_.push_back(val);
        return *this;
    }

    circular_buffer_t &insert(std::size_t pos, T val) {
        if (data_.empty()) {
            data_.push_back(std::move(val));
        } else {
            std::size_t idx = circular_index(pos);
            data_.insert(data_.begin() + idx, std::move(val));
        }
        return *this;
    }

    circular_buffer_t& erase(std::size_t pos) {
        if (!data.empty()) {
            std::size_t idx = circular_index(pos);
            data.erase(data.begin() + idx);
        }
        return *this;
    }

    T const &operator[](std::size_t i) const {
        return data[circular_index(i)];
    }

    std::size_t size() const {

    }
};
