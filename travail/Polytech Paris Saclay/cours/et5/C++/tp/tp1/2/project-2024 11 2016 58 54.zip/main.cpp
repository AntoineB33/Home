#include "circular-buffer.hpp"

#include <cassert>
#include <iostream>

int main() 
{
  circular_buffer_t<int> buffer;
  circular_buffer_t<int> const &buffer_cref = buffer;

  buffer.push_back(0);
  buffer.push_back(1);
  buffer.push_back(2);

  assert(buffer[0] == 0);
  assert(buffer[1] == 1);
  assert(buffer[2] == 2);

  assert(buffer[0 + 3] == 0);
  assert(buffer[1 + 3] == 1);
  assert(buffer[2 + 3] == 2);

  assert(buffer.size() == 3);

  buffer.insert(1, 6);
  buffer[3] = 8;

  assert(buffer_cref.size() == 4);

  assert(buffer_cref[4 + 0] == 0);
  assert(buffer_cref[4 + 1] == 6);
  assert(buffer_cref[4 + 2] == 1);
  assert(buffer_cref[4 + 3] == 8);

  circular_buffer_t<int> const buffer_copy = buffer;

  assert(buffer_copy[4 + 0] == 0);
  assert(buffer_copy[4 + 1] == 6);
  assert(buffer_copy[4 + 2] == 1);
  assert(buffer_copy[4 + 3] == 8);

  std::cout << "Tests passés avec succès.\n"; 
  return 0;
}
